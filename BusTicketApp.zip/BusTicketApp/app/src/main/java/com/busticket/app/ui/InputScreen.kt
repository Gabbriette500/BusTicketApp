package com.busticket.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun InputScreen(onPay: (busNumber: String, regNumber: String) -> Unit) {
    var busNumber by remember { mutableStateOf("") }
    var regNumber by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Оплата проезда",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1A1A1A)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Введите данные автобуса",
            fontSize = 16.sp,
            color = Color(0xFF8A8A8A)
        )

        Spacer(modifier = Modifier.height(40.dp))

        OutlinedTextField(
            value = busNumber,
            onValueChange = { busNumber = it },
            label = { Text("Номер автобуса") },
            placeholder = { Text("Например: 36") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF4DA8DA),
                unfocusedBorderColor = Color(0xFFCCCCCC),
                focusedLabelColor = Color(0xFF4DA8DA)
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = regNumber,
            onValueChange = { regNumber = it.uppercase() },
            label = { Text("Регистрационный номер") },
            placeholder = { Text("Например: P392OO") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF4DA8DA),
                unfocusedBorderColor = Color(0xFFCCCCCC),
                focusedLabelColor = Color(0xFF4DA8DA)
            )
        )

        Spacer(modifier = Modifier.height(40.dp))

        Button(
            onClick = {
                if (busNumber.isNotBlank() && regNumber.isNotBlank()) {
                    onPay(busNumber.trim(), regNumber.trim())
                }
            },
            enabled = busNumber.isNotBlank() && regNumber.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF4DA8DA),
                disabledContainerColor = Color(0xFFB0D4E8)
            )
        ) {
            Text(
                text = "Оплатить",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Стоимость: 46 ₽",
            fontSize = 15.sp,
            color = Color(0xFF8A8A8A)
        )
    }
}
