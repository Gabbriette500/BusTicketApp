package com.busticket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.busticket.app.ui.HistoryScreen
import com.busticket.app.ui.InputScreen
import com.busticket.app.ui.TicketScreen
import com.busticket.app.ui.Trip
import com.busticket.app.ui.theme.BusTicketTheme
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BusTicketTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    val navController = rememberNavController()
                    var lastTrip by remember { mutableStateOf<Trip?>(null) }

                    NavHost(
                        navController = navController,
                        startDestination = "input"
                    ) {
                        composable("input") {
                            InputScreen(
                                onPay = { busNumber, regNumber ->
                                    val today = LocalDate.now()
                                    val formatter = DateTimeFormatter.ofPattern("d MMMM, EEEE", Locale("ru"))
                                    val dateLabel = today.format(formatter)
                                        .replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale("ru")) else it.toString() }

                                    lastTrip = Trip(
                                        id = "current",
                                        busNumber = busNumber,
                                        regNumber = regNumber,
                                        dateLabel = dateLabel,
                                        status = "Поездка по билету активна",
                                        isActive = true
                                    )
                                    navController.navigate("history")
                                }
                            )
                        }

                        composable("history") {
                            HistoryScreen(
                                currentTrip = lastTrip,
                                onBack = { navController.popBackStack() },
                                onOpenTicket = { trip ->
                                    navController.navigate("ticket/${trip.busNumber}/${trip.regNumber}")
                                }
                            )
                        }

                        composable(
                            "ticket/{busNumber}/{regNumber}",
                            arguments = listOf(
                                navArgument("busNumber") { type = NavType.StringType },
                                navArgument("regNumber") { type = NavType.StringType }
                            )
                        ) { backStackEntry ->
                            val busNumber = backStackEntry.arguments?.getString("busNumber") ?: ""
                            val regNumber = backStackEntry.arguments?.getString("regNumber") ?: ""
                            TicketScreen(
                                busNumber = busNumber,
                                regNumber = regNumber,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
