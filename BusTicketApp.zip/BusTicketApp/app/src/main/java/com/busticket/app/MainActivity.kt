package com.busticket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.busticket.app.ui.InputScreen
import com.busticket.app.ui.TicketScreen
import com.busticket.app.ui.theme.BusTicketTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BusTicketTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    val navController = rememberNavController()
                    NavHost(
                        navController = navController,
                        startDestination = "input"
                    ) {
                        composable("input") {
                            InputScreen(
                                onPay = { busNumber, regNumber ->
                                    navController.navigate("ticket/$busNumber/$regNumber")
                                }
                            )
                        }
                        composable("ticket/{busNumber}/{regNumber}") { backStackEntry ->
                            val busNumber = backStackEntry.arguments?.getString("busNumber") ?: ""
                            val regNumber = backStackEntry.arguments?.getString("regNumber") ?: ""
                            TicketScreen(
                                busNumber = busNumber,
                                regNumber = regNumber,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
