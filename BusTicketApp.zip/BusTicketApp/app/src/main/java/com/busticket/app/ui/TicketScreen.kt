package com.busticket.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TicketScreen(
    busNumber: String,
    regNumber: String,
    onBack: () -> Unit
) {
    // Таймер 60 минут с миллисекундами
    var remainingMillis by remember { mutableLongStateOf(60 * 60 * 1000L) }
    val isExpired = remainingMillis <= 0

    LaunchedEffect(Unit) {
        val start = System.currentTimeMillis()
        val total = 60 * 60 * 1000L
        while (true) {
            val elapsed = System.currentTimeMillis() - start
            remainingMillis = (total - elapsed).coerceAtLeast(0)
            if (remainingMillis <= 0) break
            delay(16)
        }
    }

    val totalSeconds = (remainingMillis / 1000).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60

    val endTime = remember {
        LocalDateTime.now().plusHours(1)
    }
    val endTimeFormatted = remember {
        endTime.format(DateTimeFormatter.ofPattern("d MMMM yyyyг. до HH:mm", Locale("ru")))
    }

    val ticketBlue = if (isExpired) Color(0xFFB0C4D8) else Color(0xFF5BB5E8)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Верхняя панель без фейкового статус-бара
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF222222)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Мои билеты",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF222222)
                )
                Text(
                    text = "Указано местное время",
                    fontSize = 11.sp,
                    color = Color(0xFF999999)
                )
            }

            IconButton(onClick = {}) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Обновить",
                    tint = Color(0xFF222222)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // ===== БИЛЕТ =====
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
            ) {
                // Синяя шапка
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .background(ticketBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Автобус $busNumber",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Перфорация
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(14.dp)
                        .background(if (isExpired) Color(0xFFF5F5F5) else Color.White)
                ) {
                    val radius = 7.dp.toPx()
                    val step = 18.dp.toPx()
                    var x = 0f
                    while (x < size.width) {
                        drawCircle(
                            color = Color.White,
                            radius = radius,
                            center = Offset(x, 0f)
                        )
                        x += step
                    }
                }

                // Часть с таймером
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isExpired) Color(0xFFF5F5F5) else Color.White)
                        .padding(top = 12.dp, bottom = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isExpired) {
                        Text(
                            text = "Срок действия истёк",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFA0A0A0),
                            modifier = Modifier.padding(bottom = 18.dp)
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TimerBlock(
                            value = String.format("%02d", minutes),
                            label = "мин",
                            isExpired = isExpired
                        )
                        Text(
                            text = ":",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Light,
                            color = if (isExpired) Color(0xFFCCCCCC) else Color(0xFF5BB5E8),
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                        TimerBlock(
                            value = String.format("%02d", seconds),
                            label = "сек",
                            isExpired = isExpired
                        )
                        Text(
                            text = ":",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Light,
                            color = if (isExpired) Color(0xFFCCCCCC) else Color(0xFF5BB5E8),
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                        TimerBlock(
                            value = String.format("%03d", (remainingMillis % 1000).toInt()),
                            label = "мс",
                            isExpired = isExpired
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // ===== ДЕТАЛИ =====
            Text(
                text = "Детали",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF222222),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            DetailRow(
                icon = Icons.Default.Description,
                label = "Серия и номер",
                value = null,
                isLoading = true,
                isExpired = isExpired
            )

            DetailRow(
                icon = Icons.Default.HelpOutline,
                label = "Регистрационный номер",
                value = regNumber,
                isLoading = false,
                isExpired = isExpired
            )

            DetailRow(
                icon = Icons.Default.DirectionsBus,
                label = "Бортовой номер",
                value = null,
                isLoading = true,
                isExpired = isExpired
            )

            DetailRow(
                icon = Icons.Default.LocalTaxi,
                label = "Перевозчик",
                value = "МУП ПАТП",
                isLoading = false,
                isExpired = isExpired
            )

            DetailRow(
                icon = Icons.Default.AccessTime,
                label = "Действует до",
                value = endTimeFormatted,
                isLoading = false,
                isExpired = isExpired
            )

            DetailRow(
                icon = Icons.Default.SwapVert,
                label = "Направление",
                value = "В одну сторону",
                isLoading = false,
                isExpired = isExpired
            )

            DetailRow(
                icon = Icons.Default.ConfirmationNumber,
                label = "Количество билетов",
                value = "1",
                isLoading = false,
                isExpired = isExpired,
                showDivider = false
            )

            Spacer(modifier = Modifier.height(28.dp))

            // ===== СТОИМОСТЬ =====
            Text(
                text = "Стоимость заказа",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF222222),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF7F7F7)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Итого", fontSize = 16.sp, color = Color(0xFF222222))
                    Text(
                        text = "46₽",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF222222)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            ActionRow(icon = Icons.Default.Receipt, text = "Получить чек")
            Spacer(modifier = Modifier.height(8.dp))
            ActionRow(icon = Icons.Default.HeadsetMic, text = "Обратиться в поддержку")

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun TimerBlock(
    value: String,
    label: String,
    isExpired: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = if (isExpired) Color(0xFFEEEEEE) else Color(0xFFF0F7FC),
            modifier = Modifier.defaultMinSize(minWidth = 52.dp)
        ) {
            Text(
                text = value,
                fontSize = 26.sp,
                fontWeight = FontWeight.Medium,
                color = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF222222),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF999999)
        )
    }
}

@Composable
private fun DetailRow(
    icon: ImageVector,
    label: String,
    value: String?,
    isLoading: Boolean,
    isExpired: Boolean,
    showDivider: Boolean = true
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF777777),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF999999)
                )
                Spacer(modifier = Modifier.height(2.dp))
                if (isLoading) {
                    LoadingIndicator(isExpired = isExpired)
                } else {
                    Text(
                        text = value ?: "",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isExpired) Color(0xFF9A9A9A) else Color(0xFF222222)
                    )
                }
            }
        }
        if (showDivider) {
            HorizontalDivider(
                color = Color(0xFFEEEEEE),
                thickness = 1.dp,
                modifier = Modifier.padding(start = 34.dp)
            )
        }
    }
}

@Composable
private fun LoadingIndicator(isExpired: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "loading")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF5BB5E8)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "Загрузка...",
            fontSize = 14.sp,
            color = (if (isExpired) Color(0xFFC0C0C0) else Color(0xFF999999)).copy(alpha = alpha)
        )
    }
}

@Composable
private fun ActionRow(icon: ImageVector, text: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF7F7F7),
        onClick = {}
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF777777),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(text = text, fontSize = 15.sp, color = Color(0xFF222222))
        }
    }
}
