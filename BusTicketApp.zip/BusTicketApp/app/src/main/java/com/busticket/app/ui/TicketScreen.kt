package com.busticket.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TicketScreen(
    busNumber: String,
    regNumber: String,
    onBack: () -> Unit
) {
    var remainingMillis by remember { mutableLongStateOf(60 * 60 * 1000L) }
    val isExpired = remainingMillis <= 0

    LaunchedEffect(Unit) {
        val start = System.currentTimeMillis()
        val total = 60 * 60 * 1000L
        while (true) {
            val elapsed = System.currentTimeMillis() - start
            remainingMillis = (total - elapsed).coerceAtLeast(0)
            if (remainingMillis <= 0) break
            delay(32)
        }
    }

    val totalSeconds = (remainingMillis / 1000).toInt()
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val centiseconds = ((remainingMillis % 1000) / 10).toInt() // 2 цифры

    val endTime = remember { LocalDateTime.now().plusHours(1) }
    val endTimeFormatted = remember {
        endTime.format(DateTimeFormatter.ofPattern("d MMMM yyyyг. до HH:mm", Locale("ru")))
    }

    val ticketBlue = if (isExpired) Color(0xFFA8C4D8) else Color(0xFF5BBAE8)
    val timerAreaBg = if (isExpired) Color(0xFFF0F0F0) else Color.White
    val digitBg = if (isExpired) Color(0xFFE8E8E8) else Color(0xFFF2F8FC)
    val digitColor = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF222222)
    val colonColor = if (isExpired) Color(0xFFD0D0D0) else Color(0xFF5BBAE8)
    val labelColor = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF9A9A9A)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Шапка
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color(0xFF222222))
            }
            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Мои билеты", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF222222))
                Text("Указано местное время", fontSize = 11.sp, color = Color(0xFF999999))
            }
            IconButton(onClick = {}) {
                Icon(Icons.Default.Refresh, null, tint = Color(0xFF222222))
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            // ========== БИЛЕТ ==========
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
            ) {
                // Синяя часть
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(96.dp)
                        .background(ticketBlue),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Автобус $busNumber",
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                // Перфорация
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(12.dp)
                        .background(timerAreaBg)
                ) {
                    val r = 6.dp.toPx()
                    val step = 16.dp.toPx()
                    var x = -r
                    while (x < size.width + r) {
                        drawCircle(Color.White, radius = r, center = Offset(x, 0f))
                        x += step
                    }
                }

                // Серая / белая зона с таймером
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(timerAreaBg)
                        .padding(top = 28.dp, bottom = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (isExpired) {
                        Text(
                            text = "Срок действия истёк",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Normal,
                            color = Color(0xFFA8A8A8),
                            modifier = Modifier.padding(bottom = 20.dp)
                        )
                    }

                    // Таймер
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // Минуты
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row {
                                DigitBox(String.format("%02d", minutes)[0].toString(), digitBg, digitColor)
                                Spacer(Modifier.width(3.dp))
                                DigitBox(String.format("%02d", minutes)[1].toString(), digitBg, digitColor)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("мин", fontSize = 11.sp, color = labelColor)
                        }

                        // Двоеточие
                        Text(
                            text = ":",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Light,
                            color = colonColor,
                            modifier = Modifier.padding(horizontal = 6.dp).offset(y = (-10).dp)
                        )

                        // Секунды
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row {
                                DigitBox(String.format("%02d", seconds)[0].toString(), digitBg, digitColor)
                                Spacer(Modifier.width(3.dp))
                                DigitBox(String.format("%02d", seconds)[1].toString(), digitBg, digitColor)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("сек", fontSize = 11.sp, color = labelColor)
                        }

                        // Двоеточие
                        Text(
                            text = ":",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Light,
                            color = colonColor,
                            modifier = Modifier.padding(horizontal = 6.dp).offset(y = (-10).dp)
                        )

                        // Миллисекунды (2 цифры)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row {
                                DigitBox(String.format("%02d", centiseconds)[0].toString(), digitBg, digitColor)
                                Spacer(Modifier.width(3.dp))
                                DigitBox(String.format("%02d", centiseconds)[1].toString(), digitBg, digitColor)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("мс", fontSize = 11.sp, color = labelColor)
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))

            // ========== ДЕТАЛИ ==========
            Text(
                text = "Детали",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF222222),
                modifier = Modifier.padding(bottom = 10.dp)
            )

            DetailRow(Icons.Default.Description, "Серия и номер", null, true, isExpired)
            DetailRow(Icons.Default.HelpOutline, "Регистрационный номер", regNumber, false, isExpired)
            DetailRow(Icons.Default.DirectionsBus, "Бортовой номер", null, true, isExpired)
            DetailRow(Icons.Default.LocalTaxi, "Перевозчик", "МУП ПАТП", false, isExpired)
            DetailRow(Icons.Default.AccessTime, "Действует до", endTimeFormatted, false, isExpired)
            DetailRow(Icons.Default.SwapVert, "Направление", "В одну сторону", false, isExpired)
            DetailRow(Icons.Default.ConfirmationNumber, "Количество билетов", "1", false, isExpired, showDivider = false)

            Spacer(Modifier.height(28.dp))

            Text(
                text = "Стоимость заказа",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF222222),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF7F7F7)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Итого", fontSize = 16.sp, color = Color(0xFF222222))
                    Text("46₽", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFF222222))
                }
            }

            Spacer(Modifier.height(12.dp))
            ActionRow(Icons.Default.Receipt, "Получить чек")
            Spacer(Modifier.height(8.dp))
            ActionRow(Icons.Default.HeadsetMic, "Обратиться в поддержку")
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun DigitBox(digit: String, bg: Color, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bg,
        modifier = Modifier.size(width = 28.dp, height = 36.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Text(
                text = digit,
                fontSize = 22.sp,
                fontWeight = FontWeight.Medium,
                color = color,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun DetailRow(
    icon: ImageVector,
    label: String,
    value: String?,
    isLoading: Boolean,
    isExpired: Boolean,
    showDivider: Boolean = true
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF777777), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 12.sp, color = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF999999))
                Spacer(Modifier.height(2.dp))
                if (isLoading) {
                    LoadingIndicator(isExpired)
                } else {
                    Text(value ?: "", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = if (isExpired) Color(0xFF9A9A9A) else Color(0xFF222222))
                }
            }
        }
        if (showDivider) {
            HorizontalDivider(color = Color(0xFFEEEEEE), thickness = 1.dp, modifier = Modifier.padding(start = 34.dp))
        }
    }
}

@Composable
private fun LoadingIndicator(isExpired: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "l")
    val alpha by infiniteTransition.animateFloat(
        0.3f, 1f,
        infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "a"
    )
    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF5BBAE8)
        )
        Spacer(Modifier.width(8.dp))
        Text("Загрузка...", fontSize = 14.sp, color = (if (isExpired) Color(0xFFC0C0C0) else Color(0xFF999999)).copy(alpha = alpha))
    }
}

@Composable
private fun ActionRow(icon: ImageVector, text: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF7F7F7),
        onClick = {}
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = Color(0xFF777777), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(14.dp))
            Text(text, fontSize = 15.sp, color = Color(0xFF222222))
        }
    }
}
