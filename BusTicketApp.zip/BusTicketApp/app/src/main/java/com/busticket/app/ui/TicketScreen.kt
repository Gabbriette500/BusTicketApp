package com.busticket.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TicketScreen(
    busNumber: String,
    regNumber: String,
    onBack: () -> Unit
) {
    // Таймер на 60 минут
    var remainingSeconds by remember { mutableIntStateOf(60 * 60) }
    val isExpired = remainingSeconds <= 0

    LaunchedEffect(Unit) {
        while (remainingSeconds > 0) {
            delay(1000)
            remainingSeconds--
        }
    }

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val millis = 0 // для визуала

    // Время окончания
    val endTime = remember {
        LocalDateTime.now().plusHours(1)
    }
    val endTimeFormatted = remember {
        endTime.format(DateTimeFormatter.ofPattern("d MMMM yyyyг. до HH:mm", Locale("ru")))
    }

    // Цвета в зависимости от состояния
    val ticketBlue = if (isExpired) Color(0xFFA8C8D8) else Color(0xFF5BB8E8)
    val textMain = if (isExpired) Color(0xFF9A9A9A) else Color(0xFF1A1A1A)
    val textSecondary = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF6A6A6A)
    val timerBg = if (isExpired) Color(0xFFF0F0F0) else Color(0xFFF5F9FC)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE8F4FC))
    ) {
        // Верхняя панель статуса (имитация)
        StatusBarMock()

        // Заголовок
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF1A1A1A)
                )
            }

            Column(
                modifier = Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Мои билеты",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF1A1A1A)
                )
                Text(
                    text = "Указано местное время",
                    fontSize = 12.sp,
                    color = Color(0xFF8A8A8A)
                )
            }

            IconButton(onClick = { /* refresh */ }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Обновить",
                    tint = Color(0xFF1A1A1A)
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            // === БИЛЕТ ===
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column {
                    // Синяя верхняя часть
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                            .background(ticketBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Автобус $busNumber",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Зубчатый край
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                    ) {
                        val pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
                        drawLine(
                            color = Color(0xFFE8F4FC),
                            start = Offset(0f, size.height / 2),
                            end = Offset(size.width, size.height / 2),
                            strokeWidth = size.height,
                            pathEffect = pathEffect
                        )
                    }

                    // Белая часть с таймером
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
                            .background(Color.White)
                            .padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (isExpired) {
                            Text(
                                text = "Срок действия истёк",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF9A9A9A)
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                        }

                        // Таймер
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TimerDigit(
                                value = String.format("%02d", minutes),
                                label = "мин",
                                isExpired = isExpired
                            )
                            Text(
                                text = ":",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Light,
                                color = if (isExpired) Color(0xFFCCCCCC) else Color(0xFF4DA8DA),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                            TimerDigit(
                                value = String.format("%02d", seconds),
                                label = "сек",
                                isExpired = isExpired
                            )
                            Text(
                                text = ":",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Light,
                                color = if (isExpired) Color(0xFFCCCCCC) else Color(0xFF4DA8DA),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                            TimerDigit(
                                value = String.format("%03d", millis),
                                label = "мс",
                                isExpired = isExpired
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // === ДЕТАЛИ ===
            Text(
                text = "Детали",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            DetailItem(
                icon = Icons.Default.Description,
                label = "Серия и номер",
                value = null, // всегда загрузка
                isLoading = true,
                isExpired = isExpired
            )

            DetailItem(
                icon = Icons.Default.HelpOutline,
                label = "Регистрационный номер",
                value = regNumber,
                isLoading = false,
                isExpired = isExpired
            )

            DetailItem(
                icon = Icons.Default.DirectionsBus,
                label = "Бортовой номер",
                value = null,
                isLoading = true,
                isExpired = isExpired
            )

            DetailItem(
                icon = Icons.Default.LocalTaxi,
                label = "Перевозчик",
                value = "МУП ПАТП №2",
                isLoading = false,
                isExpired = isExpired
            )

            DetailItem(
                icon = Icons.Default.AccessTime,
                label = "Действует до",
                value = endTimeFormatted,
                isLoading = false,
                isExpired = isExpired
            )

            DetailItem(
                icon = Icons.Default.SwapVert,
                label = "Направление",
                value = "В одну сторону",
                isLoading = false,
                isExpired = isExpired
            )

            DetailItem(
                icon = Icons.Default.ConfirmationNumber,
                label = "Количество билетов",
                value = "1",
                isLoading = false,
                isExpired = isExpired,
                showDivider = false
            )

            Spacer(modifier = Modifier.height(28.dp))

            // === СТОИМОСТЬ ===
            Text(
                text = "Стоимость заказа",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1A1A1A),
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F8F8)),
                elevation = CardDefaults.cardElevation(0.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Итого",
                        fontSize = 17.sp,
                        color = Color(0xFF1A1A1A)
                    )
                    Text(
                        text = "46₽",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Кнопки внизу
            ActionButton(
                icon = Icons.Default.Receipt,
                text = "Получить чек",
                onClick = {}
            )

            Spacer(modifier = Modifier.height(10.dp))

            ActionButton(
                icon = Icons.Default.HeadsetMic,
                text = "Обратиться в поддержку",
                onClick = {}
            )

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun StatusBarMock() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFE8F4FC))
            .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Время
        Box(
            modifier = Modifier
                .background(Color(0xFF4CAF50), RoundedCornerShape(12.dp))
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Text(
                text = "02:45",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "LTE",
                fontSize = 12.sp,
                color = Color(0xFF1A1A1A),
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.width(4.dp))
            // Иконка сигнала (упрощённо)
            Text(text = "●●●●", fontSize = 10.sp, color = Color(0xFF1A1A1A))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "100",
                fontSize = 12.sp,
                color = Color(0xFF1A1A1A),
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun TimerDigit(
    value: String,
    label: String,
    isExpired: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .background(
                    color = if (isExpired) Color(0xFFEEEEEE) else Color(0xFFF0F7FC),
                    shape = RoundedCornerShape(8.dp)
                )
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Text(
                text = value,
                fontSize = 28.sp,
                fontWeight = FontWeight.Medium,
                color = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF2A2A2A),
                textAlign = TextAlign.Center
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            color = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF8A8A8A)
        )
    }
}

@Composable
private fun DetailItem(
    icon: ImageVector,
    label: String,
    value: String?,
    isLoading: Boolean,
    isExpired: Boolean,
    showDivider: Boolean = true
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF6A6A6A),
                modifier = Modifier.size(22.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    fontSize = 13.sp,
                    color = if (isExpired) Color(0xFFB0B0B0) else Color(0xFF8A8A8A)
                )
                Spacer(modifier = Modifier.height(3.dp))

                if (isLoading) {
                    LoadingDots(isExpired = isExpired)
                } else {
                    Text(
                        text = value ?: "",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isExpired) Color(0xFF9A9A9A) else Color(0xFF1A1A1A)
                    )
                }
            }
        }

        if (showDivider) {
            HorizontalDivider(
                color = Color(0xFFF0F0F0),
                thickness = 1.dp,
                modifier = Modifier.padding(start = 36.dp)
            )
        }
    }
}

@Composable
private fun LoadingDots(isExpired: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "loading")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(verticalAlignment = Alignment.CenterVertically) {
        CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF4DA8DA)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "Загрузка...",
            fontSize = 14.sp,
            color = if (isExpired) Color(0xFFC0C0C0) else Color(0xFF8A8A8A).copy(alpha = alpha)
        )
    }
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    text: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F8F8)),
        elevation = CardDefaults.cardElevation(0.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF6A6A6A),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = text,
                fontSize = 16.sp,
                color = Color(0xFF1A1A1A)
            )
        }
    }
}
