package com.busticket.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Trip(
    val id: String,
    val busNumber: String,
    val regNumber: String,
    val dateLabel: String,      // "16 ноября, понедельник"
    val status: String = "Поездка по билету завершена",
    val price: String = "46₽",
    val isActive: Boolean = false
)

@Composable
fun HistoryScreen(
    currentTrip: Trip?,
    onBack: () -> Unit,
    onOpenTicket: (Trip) -> Unit
) {
    // Фейковые прошлые поездки
    val fakeTrips = listOf(
        Trip("f1", "46", "A141YE", "16 ноября, понедельник"),
        Trip("f2", "36", "P392OO", "15 ноября, воскресенье"),
        Trip("f3", "72", "K701BC", "15 ноября, воскресенье"),
        Trip("f4", "6",  "M123KK", "14 ноября, суббота"),
        Trip("f5", "36", "P392OO", "13 ноября, пятница"),
        Trip("f6", "46", "A141YE", "13 ноября, пятница"),
        Trip("f7", "36", "P392OO", "12 ноября, четверг")
    )

    val allTrips = buildList {
        if (currentTrip != null) add(currentTrip)
        addAll(fakeTrips)
    }

    // Группируем по дате
    val grouped = allTrips.groupBy { it.dateLabel }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .statusBarsPadding()
    ) {
        // Шапка
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color(0xFF222222))
            }
            Text(
                text = "Мои заказы",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF222222),
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.width(48.dp)) // баланс для центрирования
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            grouped.forEach { (date, trips) ->
                item {
                    Text(
                        text = date,
                        fontSize = 14.sp,
                        color = Color(0xFF999999),
                        modifier = Modifier.padding(top = 16.dp, bottom = 10.dp)
                    )
                }

                items(trips) { trip ->
                    TripCard(
                        trip = trip,
                        onTicketClick = { onOpenTicket(trip) },
                        onHelpClick = { /* ничего */ }
                    )
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

@Composable
private fun TripCard(
    trip: Trip,
    onTicketClick: () -> Unit,
    onHelpClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF5F5F5)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Верхняя строка: иконка + название + цена
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Иконка автобуса
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF2B9FE8),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            Icons.Default.DirectionsBus,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Автобус ${trip.busNumber}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF222222)
                    )
                    Text(
                        text = trip.status,
                        fontSize = 13.sp,
                        color = Color(0xFF999999)
                    )
                }

                Text(
                    text = trip.price,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF222222)
                )
            }

            // Кнопки только у активного / или у всех как в референсе
            if (trip.isActive) { // показываем кнопки как в референсе на первой карточке
                Spacer(Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    // Кнопка Билет
                    Surface(
                        onClick = onTicketClick,
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFE8E8E8),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(vertical = 12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.ConfirmationNumber,
                                null,
                                tint = Color(0xFF555555),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Билет", fontSize = 14.sp, color = Color(0xFF333333))
                        }
                    }

                    Spacer(Modifier.width(10.dp))

                    // Кнопка Помощь
                    Surface(
                        onClick = onHelpClick,
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFE8E8E8),
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(vertical = 12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.HeadsetMic,
                                null,
                                tint = Color(0xFF555555),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Помощь", fontSize = 14.sp, color = Color(0xFF333333))
                        }
                    }
                }
            }
        }
    }
}
